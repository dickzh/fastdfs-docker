
/*
 * !!! DO NOT EDIT DIRECTLY !!!
 * This file was automatically generated from the following template:
 *
 * src/subsys/ngx_subsys_lua_worker.h.tt2
 */


/*
 * Copyright (C) Yichun Zhang (agentzh)
 */


#ifndef _NGX_STREAM_LUA_WORKER_H_INCLUDED_
#define _NGX_STREAM_LUA_WORKER_H_INCLUDED_


#include "ngx_stream_lua_common.h"


void ngx_stream_lua_inject_worker_api(lua_State *L);


#endif /* _NGX_STREAM_LUA_WORKER_H_INCLUDED_ */
